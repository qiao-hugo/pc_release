<?php

$languageStrings = array(
        'Hello World' => 'Hello World!',
        'LBL_WELCOME' => 'A very warm welcome to you'
);
